import ComingSoon from "./ComingSoon"
import './App.css';

function App() {
  return (
    <div className="App">
    <ComingSoon />
      </div>
  );
}

export default App;
